#ifndef BOARD_H
#define BOARD_H

#include <string>
#include <iostream>
int MAXPLAYERS = 6;

class Players;

class Board {
    int playernum; // # of players
    Players * player[MAXPLAYERS];
    int rimcups; // 0<= rimcups <= 4
    int times; // # of times the player has consecutively rolled
    int turn; // who's turn
    
public:
    Board(int playernum); // ctor
    ~Board(); // dtor
    Players * whosturn();
    void addPlayer(Players * p);
    void removePlayer(Players * p);
    void trade(string name, string give, string receive); // trade buildings
    void bankrupt();
    void save(string filename);
    void move(); // move according to rules
    void move(int dice1, int dice2); // move according to two dice
    void buyBuilding(int buildingNum, Players * p);
    void sellBuilding(int buildingNum, Players *p);
    int getRimcups();
    int getTimes();
};

#endif
