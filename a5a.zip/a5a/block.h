#ifndef BLOCK_H
#define BLOCK_H

#include <string>
int MAXPLAYERS = 6;
class Players;
class Board;
class Display;

class Block {
protected:
    int position;
    Players * playersHere[MAXPLAYERS]; // players on this block
    int numHere; // # of players on this block
    display * display;
    
private:
    string name;
    
public:
    Block(string name, int position); // ctor
    virtual ~Block();
    string getName();
    int getPosition();
    virtual action(); // do things by the rules
};

#endif
