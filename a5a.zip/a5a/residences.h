#ifndef RESIDENCES_H
#define RESIDENCES_H

#include <string>
#include "buildings.h"

class Residences : public Buildings{
public:
    Residences();
    ~Residences();
    int getRent();
    void mortgage();
    void unmortgage();
    void auction();
};

#endif
