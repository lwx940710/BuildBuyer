#ifndef PLAYERS_H
#define PLAYERS_H

#include <string>

class Display;
class Buildings;

class Players {
    const string name;
    const char c;
    int position;
    int cash;
    int asset; // total assets
    int rims; // # of rim cups this player has
    int numbuildings;
    int numresidences;
    int numgyms;
    bool stuck; // true if this player cannot move
    Display * display;
    
public:
    Players(string name, char c, int position, int cash, Display * display);
    ~Players();
    string getName();
    char getC();
    int getPosition();
    void setPosition();
    int getCash();
    void setCash();
    int getAsset();
    void setAsset();
    int getRims();
    void setRims();
    int getNum(char type); // type: b - Buildings; r - Residences; g - Gyms
    void setNum(char type);
    bool canMove(); // get stuck
    void setStuck();
    Display * getDisplay();
    void buyBuilding(Buildings * b);
    void sellBuilding(Buildings * b);
    void improve(int position);
};

#endif
