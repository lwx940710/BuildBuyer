#ifndef GOOSE_H
#define GOOSE_H

#include "block.h"

class Goose : public Block {
public:
    Goose();
    ~Goose();
    void action();
};

#endif
