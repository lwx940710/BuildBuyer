#ifndef GYMS_H
#define GYMS_H

#include "buildings.h"

class Gyms : public Buildings {
public:
    Gyms(string name, int purchase, int position, Board * b);
    ~Gyms();
    int getRent();
    void mortgage();
    void unmortgage();
    void auction();
};

#endif
