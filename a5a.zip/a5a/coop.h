#ifndef COOP_H
#define COOP_H

#include <string>

class Coop : public Block {
public:
    Coop(); // ctor
    ~Coop(); // dtor
    void action(); // do things by the rules
};

#endif
