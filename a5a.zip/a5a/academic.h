#ifndef ACADEMIC_H
#define ACADEMIC_H

#include "building.h"
class Board;
class Players;

class Academic : public Buildings {
    string name;
    string block; // monopoly block of this building
    int improve; // improvement cost
    int level; // current level of improvement
    int tuition[6];
    int monopoly[3]; // store owners of buildings in current monopoly
    
public:
    Academic(string name, string block, int purchase, int improve, 0, int[] tuition, int position); // ctor
    ~Academic(); // dtor
    void improve(); // improve this building
    int getImprove(); // get improvement cost
    void mortgage(); // to mortgage this building
    void unmortgage(); // to unmortgage this building
    bool getMortgage(); // get mortgage
    bool getRent(); // get tuition of this building
    void auction();
};

#endif
