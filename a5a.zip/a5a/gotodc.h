#ifndef GOTODC_H
#define GOTODC_H

#include "block.h"

class goToDC : public Block {
public:
    goToDC();
    ~goToDC();
    void action();
};

#endif
