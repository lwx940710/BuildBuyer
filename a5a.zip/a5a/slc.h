#ifndef SLC_H
#define SLC_H

#include "block.h"

class Slc : public Block{
public:
    Slc();
    ~Slc();
    void action();
};

#endif
