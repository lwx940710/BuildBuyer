#ifndef TUITION_H
#define TUITION_H

#include "block.h"

class Tuition : public Block{
public:
    Tuition();
    ~Tuition();
    void action();
};

#endif
