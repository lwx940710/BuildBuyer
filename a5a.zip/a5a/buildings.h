#ifndef BUILDINGS_H
#define BUILDINGS_H

#include "block.h"
class Players;
class Board;

class Buildings : public Block {
    players * owner;
    int purchase; // purchase cost
    bool mortgaged; // mortgaged or not
    int rent;
    
public:
    Board * b;
    Buildings(string name, int purchase, int position, Board * b);
    ~Buildings();
    virtual int getPurchase();
    virtual void mortgage();
    virtual void unmortgage();
    bool getMortgage();
    virtual int getRent();
    void setOwner(Players * p);
    Players* getOwner();
    virtual void auction();
    
};

#endif
