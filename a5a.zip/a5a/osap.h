#ifndef OSAP_H
#define OSAP_H

#include "block.h"

class Osap : public Block {
public:
    Osap();
    ~Osap();
    void action();
};

#endif
