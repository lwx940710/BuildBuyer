#ifndef DISPLAY_H
#define DISPLAY_H

#include <map>
#include <iostream>
#include <string>
#include <iomanip>


class Display {
protected:
    map<string name, int position> player; // store name and position of player
    map<int, string> improvemen; //first  position of the building, second number of improvement
    map<int, string> acaorgym;//first  position of the building second owner
public:
	Display(); // ctor
    ~Display(); // dtor
	void notifyPlayer(string name, int position); // notify display when player moves
	void notifyAcademic(int position, int level, string name); // notify display when building is improvd
	void notifyRG(int position, string name); // notify display when residence and gyms are purchased
	void print(ostream &out);
};

#endif
