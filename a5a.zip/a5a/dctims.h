#ifndef DCTIMS_H
#define DCTIMS_H

#include <string>

class Board;

class Dctims : public Block {
public:
    Dctims();
    ~Dctims();
    void action();
};

#endif
