#ifndef NEEDLES_H
#define NEEDLES_H


#include "block.h"
#include <string>
#include <iostream>
#include <cstdlib>
#include <ctime>


class Board;

class Needles: public Block{
    board * b;
    
public:
    Needles(int position, Board * b);
    ~needles();
    void action();
};

#endif
