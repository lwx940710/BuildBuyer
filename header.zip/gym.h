#ifndef GYM_H
#define GYM_H

#include "property.h"

class Gyms : public Property {
public:
    int getRent();
    void event();
};

#endif
