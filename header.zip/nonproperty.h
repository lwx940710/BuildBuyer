#ifndef NONPROPERTY_H
#define NONPROPERTY_H

#include <string>
#include "building.h"

class NonProperty : public Building {
public:
    virtual void event();
};

#endif
