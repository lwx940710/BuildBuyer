#ifndef ACADEMIC_H
#define ACADEMIC_H

#include "property.h"
class Board;
class Players;

class Academic : public Property {
    string block; // monopoly block of this building
    int level; // current level of improvement
    int improvementCost;
    int tuition[6];
    
protected:
    int countOwnership();
    
public:
    int getLevel();
    int getImprovementCost();
    void levelUp();
    void levelDown();
    bool canUpgrade();
    void getRent();
    string getBlock();
    void event();
    
};

#endif
