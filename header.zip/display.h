#ifndef DISPLAY_H
#define DISPLAY_H

#include <map>
#include <iostream>
#include <string>
#include <iomanip>


class Display {
private:
    char ** board;
    char * player;
    int numPlayer;
    int numCurrent;
    int playerAtRow(int pos, char name);
    int playerAtColumn(int pos, char name);
    int buildingAtRow(int pos, char name);
    int buildingAtColumn(int pos, char name);
    
public:
	void positionNotify(int prev, int curr, char name);
    void academicNotify(int position, int level, char name, bool mortgaged);
    void nonAcademicNotify(int position, int level, string name, bool mortgaged);
    void addPlayer(char name);
    void removePlayer(char name, int pos);
    void print();
};

#endif
