#ifndef NEEDLES_H
#define NEEDLES_H


#include "nonproperty.h"
#include <string>
#include <iostream>
#include <cstdlib>
#include <ctime>


class Needles: public NonProperty {
public:
    void event();
};

#endif
