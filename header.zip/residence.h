#ifndef RESIDENCE_H
#define RESIDENCE_H

#include <string>
#include "property.h"

class Residences : public Property {
public:
    int getRent();
    void event();
};

#endif
