#ifndef PLAYER_H
#define PLAYER_H

#include <string>
#include <map>

class Game;
class Buildings;
class Property;

class Players {
    const string name;
    const char symbol;
    int position;
    double cash;
    map<string, Building *> property;
    int rim; // # of rim cups this player has
    bool canMove; // true if this player can move
    Game * game;
    int timsCounter;
    map<string, int> counter;
    
public:
    string getName();
    char getSymbol();
    double getCash();
    void addCash(double amount);
    void payCash(double amount);
    void setCash(double amount);
    bool useRim();
    void addRim();
    void setRim();
    bool getCanMove();
    void setCanMove(bool m);
    void move(int step);
    void setPosition(int p);
    int getPosition();
    void addProperty(Property * p);
    void removeProperty(Property * p);
    void countMonopoly(string type);
    void printAssets();
    int getTotalAssets;
    void setTimsCounter(int n);
    int getTimsCounter();
};

#endif
