#ifndef COOP_H
#define COOP_H

#include "nonproperty.h"

class Coop : public NonProperty {
public:
    void event();
};

#endif
