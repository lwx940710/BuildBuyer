#ifndef GOOSE_H
#define GOOSE_H

#include "nonproperty.h"

class Goose : public NonProperty {
public:
    void event();
};

#endif
