#ifndef SLC_H
#define SLC_H

#include "nonproperty.h"

class Slc : public NonProperty {
public:
    void event();
};

#endif
