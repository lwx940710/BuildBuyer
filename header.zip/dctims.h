#ifndef DCTIMS_H
#define DCTIMS_H

#include <string>
#include "nonproperty.h"

class Dctims : public NonProperty {
public:
    void event();
};

#endif
