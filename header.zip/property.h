#ifndef PROPERTY_H
#define PROPERTY_H

#include <string>
#include "building.h"

class NonProperty : public Building {
protected:
    Player * owner;
    int puchaseCost;
    bool mortgaged;
    virtual getRent();
    
private:
    bool prevMortgaged;
    
public:
    void setOwner(Player * p);
    void changeOwner(Player * p); // difference between these two?
    Player * getOwner();
    int getPurchaseCost();
    void mortgage();
    void unmortgage();
    void setMortgage();
    bool getMortgaged();
    void setPrevMortgaged(bool b);
    virtual void event();
};

#endif
