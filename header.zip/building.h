#ifndef BUILDING_H
#define BUILDING_H

#include "game.h"

class Building : public Game {
protected:
    string name;
    int position;
    string type;
    Game * game;
    
public:
    string getName();
    string getType();
    virtual void event();
    
};

#endif
