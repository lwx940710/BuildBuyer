#ifndef GOTOTIMS_H
#define GOTOTIMS_H

#include "block.h"

class goToTims : public Block {
public:
    goToTims();
    ~goToTims();
    void action();
};

#endif
