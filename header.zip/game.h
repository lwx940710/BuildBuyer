#ifndef GAME_H
#define GAME_H

#include <string>
#include <iostream>
#include <map>

int MAXPLAYERS = 6;
int MAXRIM = 4;

class Players;
class Building;
class Controller;

class Game {
    Building * board[40];
    map<string, Player *> players;
    int numplayers;
    int numrims;
    Controller * c;
    map<string, Player *> current_iterator;
    Building* findBuilding(string name);
    void mortgageTransfer(Property * p, string name);
    bool checkMonopoly(Property * p);
    void auction(Property * p, string name);
    void noMoney(double m, Player * p, Player * owner);
    void bankrupt(Player * p, Player * Owner);
    
public:
    void purchaseNotify(Building * b);
    void movedPlayer(int prev, int curr, char c);
    void removePlayer(string name);
    void move(int n);
    bool getTest();
    void osapNotify();
    void tuitionNotify();
    void timsNotify();
    void tims();
    bool rimReachesMax();
    void getRim();
    void propertyImprove(Property * p);
    void updatePlayer(string name, char ch, int a, double b, int c, int d, int e); // no idea what a-e are
    void setUp();
    void setCurrentPlayer(Player * p);
    Player* getCurrentPlayer();
    void setProperty(string a, string b, int pos); // no idea what a,b are
    void addPlayer(string name, char ch);
    int getNumPlayer();
    void improve(string name); // name: building name
    void sellImprovement(string name, string building_name); // name: player name
    void mortgage(string name, string building_name);
    void unmortgage(string name, string building_name);
    void pay(double amount, string from, string to);
    void totalAssets(string name);
    void saveGame();
    void printWinner();
    bool status();
    void trade(string a, string b, int c, string d);
    void next();
};

#endif
