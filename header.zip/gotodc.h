#ifndef GOTODC_H
#define GOTODC_H

#include "nonproperty.h"

class goToDC : public NonProperty {
public:
    void event();
};

#endif
