#ifndef OSAP_H
#define OSAP_H

#include "nonproperty.h"

class Osap : public NonProperty {
public:
    void event();
};

#endif
