#ifndef CONTROLLER_H
#define CONTROLLER_H

#include <string>
#include <iostream>
#include <map>

class Game;
class Display;

class Controller {
    Display * display;
    Game * game;
    string input;
    bool test;
    int rollNum;
    bool rollDouble;
    void init();
    
public:
    bool getTest();
    void setTest();
    void load(string input);
    void play();
    void save(string filename);
    void load(string filename);
    void moveNotify(int prev, int curr, char name);
    void removePlayerNotify(int pos, char name);
    void academicNotify(int pos, int level, char name);
    void nonAcademicNotify(int pos, char name, bool mortgaged);
};

#endif
